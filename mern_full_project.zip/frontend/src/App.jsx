
import React, { useState, useEffect } from "react";

export default function App(){
  const [customerName,setCustomerName]=useState("");
  const [amount,setAmount]=useState("");
  const [date,setDate]=useState("");
  const [bills,setBills]=useState([]);

  const submit = async()=>{
    await fetch("http://localhost:5000/api/bill",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({customerName,amount,date})
    });
    load();
  };

  const load = async()=>{
    const res = await fetch("http://localhost:5000/api/bill");
    setBills(await res.json());
  };

  useEffect(()=>{load();},[]);

  return(
    <div style={{padding:20}}>
      <h2>Bill Form</h2>
      <input placeholder="Customer Name" value={customerName} onChange={e=>setCustomerName(e.target.value)} /><br/><br/>
      <input placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)} /><br/><br/>
      <input placeholder="Date" value={date} onChange={e=>setDate(e.target.value)} /><br/><br/>
      <button onClick={submit}>Save</button>

      <h2>Saved Bills</h2>
      {bills.map(b=>(
        <div key={b._id}>{b.customerName} - {b.amount} - {b.date}</div>
      ))}
    </div>
  );
}
